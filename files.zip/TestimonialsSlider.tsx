import React, { useState, useEffect, useCallback, useRef } from 'react';
import { ChevronLeft, ChevronRight, Quote } from 'lucide-react';

const testimonials = [
  {
    name: 'Payal Khemchandani',
    loc: 'Delhi NCR',
    year: '2026',
    quote:
      'The teasers, reels, and our wedding film were beautifully edited and perfectly captured the emotions and energy of each event. Our album has turned out absolutely stunning — every page feels thoughtfully designed.',
  },
  {
    name: 'Shivangi',
    loc: 'Delhi',
    year: '2026',
    quote:
      'They have given us videos and pictures that we will look at when we are 80 and laugh. No one could have done a better job. Very passionate people I must say.',
  },
  {
    name: 'Anisha Srivastava',
    loc: 'Delhi NCR',
    year: '2026',
    quote:
      'Every photo and reel they delivered is nothing short of stunning. The attention to detail, the storytelling, the way they captured every emotion — our reels are cinematic, vibrant, crafted with so much love.',
  },
  {
    name: 'Mansi Saini',
    loc: 'Delhi',
    year: '2025',
    quote:
      'From the reels to the pictures to the album — everything was just wow. The team was super sweet, professional, and made us feel so comfortable. Couldn\'t have asked for a better team.',
  },
];

export const TestimonialsSlider: React.FC = () => {
  const [active, setActive] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const autoplayRef = useRef<number | null>(null);

  const nextSlide = useCallback(() => {
    setActive((prev) => (prev + 1) % testimonials.length);
  }, []);

  const prevSlide = useCallback(() => {
    setActive((prev) => (prev - 1 + testimonials.length) % testimonials.length);
  }, []);

  // Stable autoplay using ref to avoid stale closure issues
  useEffect(() => {
    if (isPaused) return;
    autoplayRef.current = window.setInterval(nextSlide, 6000);
    return () => {
      if (autoplayRef.current) clearInterval(autoplayRef.current);
    };
  }, [isPaused, nextSlide]);

  return (
    <>
      {/* Progress animation defined in index.css now, but fallback here */}
      <style>{`
        @keyframes testimonial-progress {
          0% { transform: scaleX(0); }
          100% { transform: scaleX(1); }
        }
        .animate-testimonial-progress {
          animation: testimonial-progress 6s linear infinite;
        }
      `}</style>

      <section
        className="py-32 bg-ivory text-royalGreen relative overflow-hidden"
        onMouseEnter={() => setIsPaused(true)}
        onMouseLeave={() => setIsPaused(false)}
      >
        {/* Decorative quote mark */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-[35rem] font-serif text-royalGreen/[0.03] select-none pointer-events-none leading-none">
          &ldquo;
        </div>

        <div className="max-w-7xl mx-auto px-6 relative z-10">
          <header className="text-center mb-20">
            <div className="inline-block mb-6">
              <Quote className="w-8 h-8 text-antiqueGold/40 mx-auto mb-4" />
              <h3 className="font-sans text-[10px] tracking-[0.6em] uppercase text-antiqueGold font-bold">
                Featured Narratives
              </h3>
            </div>
            <h2 className="font-serif text-5xl md:text-7xl text-charcoal leading-tight">
              Voices of the <span className="italic font-light">Legacy</span>
            </h2>
            {/* WedMeGood badge */}
            <a
              href="https://www.wedmegood.com/profile/Dipak-Studios-226/reviews"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-3 mt-6 px-6 py-3 border border-antiqueGold/20 hover:border-antiqueGold/40 transition-all"
            >
              <div className="flex gap-0.5">
                {[...Array(5)].map((_, i) => (
                  <svg key={i} className="w-3 h-3 text-antiqueGold" fill="currentColor" viewBox="0 0 20 20">
                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                  </svg>
                ))}
              </div>
              <span className="font-sans text-[9px] uppercase tracking-[0.3em] text-royalGreen/50 font-bold">
                4.8 · 203 Reviews · WedMeGood
              </span>
            </a>
          </header>

          <div className="relative group/slider max-w-5xl mx-auto">
            {/* Arrows */}
            <button
              onClick={prevSlide}
              aria-label="Previous"
              className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-4 md:-translate-x-16 z-20 p-4 rounded-full border border-antiqueGold/20 text-antiqueGold hover:bg-antiqueGold hover:text-white transition-all duration-500 opacity-0 group-hover/slider:opacity-100 hidden md:flex items-center justify-center"
            >
              <ChevronLeft className="w-6 h-6" />
            </button>
            <button
              onClick={nextSlide}
              aria-label="Next"
              className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-4 md:translate-x-16 z-20 p-4 rounded-full border border-antiqueGold/20 text-antiqueGold hover:bg-antiqueGold hover:text-white transition-all duration-500 opacity-0 group-hover/slider:opacity-100 hidden md:flex items-center justify-center"
            >
              <ChevronRight className="w-6 h-6" />
            </button>

            {/* Slides */}
            <div className="overflow-hidden">
              <div
                className="flex transition-transform duration-1000 ease-in-out"
                style={{ transform: `translateX(-${active * 100}%)` }}
              >
                {testimonials.map((t, i) => (
                  <div
                    key={i}
                    className={`min-w-full px-4 md:px-12 text-center transition-opacity duration-700 ${
                      active === i ? 'opacity-100' : 'opacity-0'
                    }`}
                  >
                    <p className="font-serif text-2xl md:text-4xl text-charcoal/80 italic leading-relaxed mb-12 max-w-3xl mx-auto">
                      "{t.quote}"
                    </p>
                    <div className="space-y-3">
                      <div className="w-8 h-px bg-antiqueGold/40 mx-auto mb-4" />
                      <p className="font-serif text-2xl text-charcoal">{t.name}</p>
                      <p className="text-[10px] uppercase tracking-[0.4em] text-antiqueGold font-bold flex items-center justify-center gap-2">
                        <span>{t.loc}</span>
                        <span className="w-1 h-1 rounded-full bg-antiqueGold/30" />
                        <span>{t.year}</span>
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Dots */}
            <div className="flex justify-center items-center space-x-4 mt-16">
              {testimonials.map((_, i) => (
                <button
                  key={i}
                  onClick={() => setActive(i)}
                  aria-label={`Go to slide ${i + 1}`}
                  className="relative group p-2"
                >
                  <div
                    className={`h-1 rounded-full transition-all duration-700 ${
                      active === i ? 'w-10 bg-antiqueGold' : 'w-4 bg-antiqueGold/20 group-hover:bg-antiqueGold/40'
                    }`}
                  />
                  {active === i && !isPaused && (
                    <div className="absolute inset-0 h-1 top-2 bg-antiqueGold/10 origin-left animate-testimonial-progress" />
                  )}
                </button>
              ))}
            </div>
          </div>

          {/* Mobile arrows */}
          <div className="mt-8 text-center md:hidden">
            <div className="flex items-center justify-center gap-4">
              <button onClick={prevSlide} className="p-3 border border-antiqueGold/20 rounded-full">
                <ChevronLeft className="w-5 h-5 text-antiqueGold" />
              </button>
              <button onClick={nextSlide} className="p-3 border border-antiqueGold/20 rounded-full">
                <ChevronRight className="w-5 h-5 text-antiqueGold" />
              </button>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};
