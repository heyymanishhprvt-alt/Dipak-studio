# Dipak Studios — Production Upgrade Guide

## What Changed

This upgrade covers 14 files replacing all placeholder content with real assets, 
working form submissions, and corrected data throughout.

---

## Files Delivered

### Drop into `/src/components/`
- `Logo.tsx` — Now uses actual `/logo.png` from public folder
- `Hero.tsx` — Fixed broken CTA + real trust stats bar (4.8★, 203 reviews, 1.56L YT subs)
- `LegacyFounders.tsx` — Real founder photos, correct name (Mr. Sunder Dipak)
- `PortfolioGrid.tsx` — Real WedMeGood images, working category filter
- `ReviewWall.tsx` — Real reviews with WedMeGood verified badge & link
- `EnquirySection.tsx` — Working dual WhatsApp + Email submission
- `LeadPopup.tsx` — Working dual submission
- `Footer.tsx` — All verified social links (Instagram, YouTube @DipakStudiosdelhi, Facebook)

### Drop into `/src/pages/`
- `Home.tsx` — Hero now receives `onNavigate` (fixes broken CTA), real images throughout
- `Films.tsx` — Real WedMeGood thumbnails, links to YouTube channel
- `Services.tsx` — 6-service grid (added Photobooth, Traditional Video, Pre-Wedding Films)
- `Booking.tsx` — Working WhatsApp + Email dual submission
- `About.tsx` — Correct founder name, real photos
- `Home.tsx`

### Drop into `/src/`
- `constants.ts` — All real data: images, reviews, social links, pricing
- `index.css` — Added missing `animate-fadeIn` and other keyframes

---

## Required: Add Real Images to Public Folder

Place these uploaded files directly in your `/public` directory:

```
/public/logo.png               ← The actual Dipak Studios logo
/public/founder-sunderdipaksir.png  ← Mr. Sunder Dipak solo portrait
/public/legacyfounders.png     ← Family team photo (all 4 members)
```

---

## How Form Submissions Work (Zero Backend Required)

All three lead forms (Hero CTA → Booking, EnquirySection, LeadPopup) now 
offer two submission buttons:

**WhatsApp** — Opens `wa.me/918527274260` with pre-filled message containing all form data. 
The team receives an instant WhatsApp message. No setup required.

**Email** — Opens the user's mail client with `wedding.dipak@gmail.com` pre-filled 
with a structured form body. No backend required.

To upgrade to a server-side form handler later, replace the `buildWhatsAppURL` / `buildMailto` 
calls in `constants.ts` with a `fetch()` POST to Formspree or EmailJS.

---

## Verified Social Links

| Platform    | URL                                              |
|-------------|--------------------------------------------------|
| Instagram   | instagram.com/dipak_studios                      |
| YouTube     | youtube.com/@DipakStudiosdelhi (1.56L subs)      |
| Facebook    | facebook.com/Dipak.Studio                        |
| Google Biz  | g.page/dipakstudiosdelhi                         |
| WhatsApp    | +91 85272 74260                                  |
| Email       | wedding.dipak@gmail.com                          |
| WedMeGood   | wedmegood.com/profile/Dipak-Studios-226 (4.8★)   |

---

## Remaining Optional Improvements

1. **Formspree integration** — Sign up at formspree.io, get an endpoint, 
   replace mailto with `fetch('https://formspree.io/f/YOUR_ID', { method: 'POST' })`.

2. **Real YouTube video IDs** — Replace the YouTube search links in `Films.tsx` 
   with specific video IDs from the channel once identified.

3. **Calendly** — Replace `https://calendly.com/` in LegacyFounders with the 
   actual account URL (e.g., `calendly.com/dipakstudios`).

4. **Blog** — Connect to a headless CMS (Sanity, Contentful) or replace static 
   posts with real articles.

5. **Client Portal** — Replace hardcoded password with Firebase Auth or Supabase.
